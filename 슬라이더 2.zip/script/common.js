let liLength = $("#slider li").length; // li의 갯수
let num = 0; // 인덱스번호
let state = 1;

function nextSlider() {
  $("#slider li:eq(1)").addClass('active')
                       .css({ opacity: 0 })
                       .animate({ opacity: 1 }, 1000, function() {
                          $("#slider").append($("#slider li:eq(0)"));
                          $("#slider li:last").removeClass('active');
                       })
  
  num++;
  if ( num == 5) num = 0;
  console.log(num)
  $("#btnNum a").removeClass('on');
  $("#btnNum a:eq("+ num  +")").addClass('on');
}
function prevSlider() {
  $("#slider li:last").addClass('active')
                      .css({ opacity: 0 })
                      .animate({ opacity: 1 }, 1000, function() {
                          $('#slider').prepend($("#slider li:last"));
                          $("#slider li:eq(1)").removeClass('active');
                      })
  num--;
  if ( num == -1) num = 4;
  $("#btnNum a").removeClass('on');
  $("#btnNum a:eq("+ num  +")").addClass('on');
}


$('.nextBtn').on('click', function() {
  nextSlider();
})
$('.prevBtn').on('click', function() {
  prevSlider();
})
$("#btnNum a").on('click', function() {
  $("#btnNum a").removeClass('on');
  $(this).addClass('on');
  let index = $(this).index() + 1;
  num = index;
  $(".slider"+ index).addClass('active')
                     .css({ opacity: 0 })
                     .animate({ opacity: 1 }, 1000, function() {
                          $("#slider li").not($(this)).removeClass('active');
                          for ( let i=0 ; i<liLength-1; i++ ) {
                              if ( num == 5) num = 0;
                              num++;
                              $("#slider").append($(".slider" + num ))
                          }
                     })
})