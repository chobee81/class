let liLength = $("#slider li").length; // li의 갯수
let num = 0; // 인덱스번호
let index = 0;
let state = 1;
// 초기설정
$("#slider li:eq(0)").css({ zIndex: 1 })


// 번호버튼
$("#btnNum a").on('click', function() {
  num = $(this).index(); // 0 1 2 3 4
  index++;
  $("#slider li:eq("+num+")").css({ zIndex: index,  opacity: 0 })
                            .animate({ opacity: 1 }, function() {
                              index = 1;
                              $("#slider li").not($(this)).css({ zIndex: 0 });
                              $(this).css({ zIndex: 1 })
                            })
})