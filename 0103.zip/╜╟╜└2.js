const gnbList = document.getElementById('gnbList');
const list = document.querySelectorAll('#gnbList > li');
const gnbName = document.querySelectorAll('#gnbList > li > a');
const snb = document.querySelectorAll('.snb');

// snb의 위치 중간으로 맞추기
function snbPos() {
  list.forEach((lis)=> {    
    let liWidth = lis.offsetWidth / 2;
    let liPosLeft = lis.offsetLeft;
    if ( lis.children.length == 2) {
      lis.children[1].style.left = `${liWidth+liPosLeft}px`;
      lis.children[1].style.transform = `translateX(-50%)`;
    }
    lis.firstElementChild.addEventListener('mouseenter', (e)=> {
      if ( lis.children.length == 2) {
        lis.firstElementChild.nextElementSibling.style.opacity = 1;
      }
    })
    lis.addEventListener('mouseleave', (e)=>{
      if ( lis.children.length == 2) {
        lis.children[1].style.opacity = 0;
      }
    })
  })
}
snbPos();
window.addEventListener('resize', ()=> {
  snbPos();
})

