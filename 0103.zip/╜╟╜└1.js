const content = document.querySelectorAll('.content');
let winHeight = window.innerHeight/2;

function scrollHandler() {
  // if (window.scrollY >= content[0].offsetTop ) content[0].style.opacity = 1;
  // if (window.scrollY >= content[1].offsetTop ) content[1].style.opacity = 1;
  // if (window.scrollY >= content[2].offsetTop ) content[2].style.opacity = 1;
  content.forEach((con) => {
    if (window.scrollY >= con.offsetTop-winHeight) {
      con.style.opacity = 1;
    }
  })
}

window.addEventListener('scroll', ()=> {
  scrollHandler();
})