let num = 0;

// 좌우버튼 클릭시 슬라이드
$(".nextBtn").on('click', function() {
  num++;
  if ( num === 5 ) {
    num = 0;
    $('#slider').append($('#slider li:first'))
                .append($('#slider li:first'))
                .append($('#slider li:first'))
                .append($('#slider li:first'))
                .css({ marginLeft: 0 })
                .animate({ marginLeft: '-100%'}, 500, function() {
                  $('#slider').append($('#slider li:first'))
                              .css({ marginLeft: 0 })
                })
  }
  else {
    $("#slider").animate({ marginLeft: `-=100%` }, 500)
  }
})

// 번호버튼 클릭시 슬라이드
$("#btnNum a").on('click', function() {
  $("#slider").animate({ marginLeft: `${$(this).index() * (-100)}%` })
})