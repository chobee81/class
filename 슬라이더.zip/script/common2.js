let num = 0;
let state = 1;
// 좌우버튼 클릭시 슬라이드
function sliderPrev() {
  num--;
  if ( num === -1 ) {
    num = 4;
    $('#slider').prepend($('#slider li:last'))
                .prepend($('#slider li:last'))
                .prepend($('#slider li:last'))
                .prepend($('#slider li:last'))
                .css({ marginLeft: '-400%'})
                .animate({ marginLeft: '-300%' }, 500, function() {
                  state = 1;
                  $('#slider').prepend($('#slider li:last'))
                              .css({ marginLeft: '-400%'})
                })
  }
  else {
    $("#slider").animate({ marginLeft: `+=100%` }, 500, function() {
      state = 1;
    })
  }
  $("#btnNum a").removeClass('on');
  $("#btnNum a:eq("+ num +")").addClass('on');
}
function sliderNext() {
  num++;
  if ( num === 5 ) {
    num = 0;
    $('#slider').append($('#slider li:first'))
                .append($('#slider li:first'))
                .append($('#slider li:first'))
                .append($('#slider li:first'))
                .css({ marginLeft: 0 })
                .animate({ marginLeft: '-100%'}, 500, function() {
                  state = 1;
                  $('#slider').append($('#slider li:first'))
                              .css({ marginLeft: 0 })
                })
  }
  else {
    $("#slider").animate({ marginLeft: `-=100%` }, 500, function() {
      state = 1;
    })
  }
  $("#btnNum a").removeClass('on');
  $("#btnNum a:eq("+ num +")").addClass('on');
}

let timer = setInterval(sliderNext, 2000)

$(".nextBtn").on('click', function() {
  if (state == 1) {
    state = 0;
    sliderNext();
  }
})
$('.prevBtn').on('click', function() {
  if (state ==1 ) {
    state = 0;
    sliderPrev();
  }
})

// 번호버튼 클릭시 슬라이드
$("#btnNum a").on('click', function() {
  num = $(this).index();
  $("#btnNum a").removeClass('on');
  $(this).addClass('on');
  $("#slider").animate({ marginLeft: `${num * (-100)}%` })
})
$("#btnPos a, #btnNum a").on('click', function(e) {
  e.preventDefault();
  clearInterval(timer);
})
$("#playBtn").on('click', function(e) {
  e.preventDefault();
  timer = setInterval(sliderNext, 2000)
})