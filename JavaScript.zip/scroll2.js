const gnb = document.querySelector('nav');
// 스크롤이벤트 발생시 한번만 실행되도록 조건문 수정
// let state = true;
// window.addEventListener('scroll', ()=> {
//   if ( window.scrollY >= 500 && state) {
//     gnb.classList.add('active');
//     state = false;
//     console.log(window.scrollY)
//   }
//   else if ( window.scrollY < 500 ) {
//     gnb.classList.remove('active')
//     state = true;
//     console.log(window.scrollY)
//   }
// })

