// document.addEventListener('DOMContentLoaded', ()=> {
  document.body.querySelector('div').style.color = 'blue';
// })