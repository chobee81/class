function navHandler() {
  if ( $(window).width() > 800 ) {
    $("#gnb").removeClass('mobile').addClass('active');    
  }
  else {
    $("#gnb").removeClass('active');
  }
}
navHandler();
$(window).on('resize', function() {
  navHandler();
})

$(document).on('mouseenter','.active', function() {
  $(".active > #gnbList").stop().animate({ height: 300 })
})
$(document).on('mouseleave','.active', function() {
  $(".active > #gnbList").stop().animate({ height: 75 })
})

$(".mobileBtn").on('click', function() {
  $("#gnb").addClass('mobile');
})
$(".mobileClose").on('click', function() {
  $("#gnb").removeClass('mobile')
})

