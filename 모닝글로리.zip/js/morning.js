
$('#gnb').on('mouseenter', function () {
    $('#header').addClass('on')


})
$('#gnb').on('mouseleave', function () {
    $('#header').removeClass('on')
})

// aboutUs

// 첫 번째 카운터
const $counters1 = $(".counter1");
const exposurePercentage = 100;
const duration1 = 600;
const addCommas1 = false;

// 두 번째 카운터
const $counters2 = $(".counter2");
const duration2 = 1700;
const addCommas2 = false;

// introduction 도달시
const $introduction = $("#introduction");

// newsNotice 도달시
const $newsNotice = $("#newsNotice");


function updateCounter($el, start, end, duration, addCommas) {
    let startTime;
    function animateCounter(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = (timestamp - startTime) / duration;
        const current = Math.round(start + progress * (end - start));
        const formattedNumber = addCommas ? current.toLocaleString() : current;
        $el.text(formattedNumber);

        if (progress < 1) {
            requestAnimationFrame(animateCounter);
        } else {
            $el.text(addCommas ? end.toLocaleString() : end);
        }
    }
    requestAnimationFrame(animateCounter);
}

// 스크롤 이벤트 병합
$(window).on('scroll', function () {
    // 첫 번째 카운터
    const winHeight = window.innerHeight;
    $counters1.each(function () {
        const $el = $(this);
        if (!$el.data('scrolled')) {
            const rect = $el[0].getBoundingClientRect();
            console.log(rect)
            const contentHeight = rect.bottom - rect.top;

            if (rect.top <= winHeight - (contentHeight * exposurePercentage / 100) && rect.bottom >= (contentHeight * exposurePercentage / 100)) {
                const start = parseInt($el.data("start"));
                const end = parseInt($el.data("end"));
                updateCounter($el, start, end, duration1, addCommas1);
                $el.data('scrolled', true);

            }
            $("#aboutUs #count .num1").addClass("active");

        }
    });

    // 두 번째 카운터
    $counters2.each(function () {
        const $el = $(this);
        if (!$el.data('scrolled')) {
            const rect = $el[0].getBoundingClientRect();
            const contentHeight = rect.bottom - rect.top;
            if (rect.top <= winHeight - (contentHeight * exposurePercentage / 400) && rect.bottom >= (contentHeight * exposurePercentage / 400)) {
                const start = parseInt($el.data("start"));
                const end = parseInt($el.data("end"));
                updateCounter($el, start, end, duration2, addCommas2);
                $el.data('scrolled', true);
            }
        }

    });

    // introduction 도달시   
    $introduction.each(function () {
        const $el = $(this);
        const rect = $el[0].getBoundingClientRect();
        const contentHeight = rect.bottom - rect.top;
        if (rect.top <= winHeight - (contentHeight * exposurePercentage / 400)) {
            $el.css({ scale: 1 })

        }
        else {
            $el.css({ scale: 0.5 })
            $("#introduction .business").css({ zIndex: 1 })
        }
    });

    // 소식 도달시
    $newsNotice.each(function () {
        const $el = $(this);
        const $heading = $el.find('h2')
        const rect = $el[0].getBoundingClientRect();
        const contentHeight = rect.bottom - rect.top;
        if (rect.top <= winHeight - (contentHeight * exposurePercentage / 200)) {
            $heading.addClass('on')
        }
        else {
            $heading.removeClass('on')

        }
    });

}).scroll();

$("#introduction article h3 span").on('mouseenter', function() {
    $("#introduction .business").css({ zIndex: 1 })
    $(this).parent().next().css({ zIndex: 10 })
})





